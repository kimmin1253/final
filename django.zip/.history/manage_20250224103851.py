import os
import sys

# 프로젝트 루트 (`D:\projects\fin\`)를 sys.path에 추가하여 Django가 올바르게 설정 파일을 찾을 수 있도록 함
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

def main():
    """Run administrative tasks."""
    # Django 설정 파일을 config.settings로 명확하게 지정
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

    try:
        from django.core.management import execute_from_command_line  # Django 명령어 실행 모듈 불러오기
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc

    execute_from_command_line(sys.argv)  # 사용자가 입력한 Django 명령어 실행

if __name__ == '__main__':
    main()
