from django.contrib import admin
from .models import YouTubeVideo

admin.site.register(YouTubeVideo)
