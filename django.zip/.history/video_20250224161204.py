import os
import sys
import django
from googleapiclient.discovery import build
from django.utils.timezone import make_aware
from datetime import datetime
from ai_model.models import YouTubeVideo

# 현재 파일(video.py)이 위치한 폴더 기준으로 프로젝트 경로를 찾음
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # `/fin/django/`
sys.path.append(BASE_DIR)

# Django 환경 설정 (manage.py 방식 적용)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend.settings")

# Django 설정 적용
django.setup()


# YouTube API Key 설정
YOUTUBE_API_KEY = "AIzaSyDgys8eFKRtcGCtyBXgck4J5MosXzeAPgQ"

def search_youtube_videos(query, max_results=30):
    """유튜브 API를 사용하여 영상 검색"""
    youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
    request = youtube.search().list(
        q=query,
        part="snippet",
        type="video",
        maxResults=max_results
    )
    response = request.execute()

    video_list = []
    for item in response["items"]:
        video_id = item["id"]["videoId"]
        title = item["snippet"]["title"]
        channel_name = item["snippet"]["channelTitle"]
        published_at = item["snippet"]["publishedAt"]
        description = item["snippet"].get("description", "")
        thumbnail_url = item["snippet"]["thumbnails"]["high"]["url"]

        # 날짜 변환 (ISO 8601 -> Django DateTimeField 형식)
        published_at_dt = make_aware(datetime.strptime(published_at, "%Y-%m-%dT%H:%M:%SZ"))

        video_list.append({
            "video_id": video_id,
            "title": title,
            "channel_name": channel_name,
            "published_at": published_at_dt,
            "description": description,
            "thumbnail_url": thumbnail_url
        })

    return video_list

def save_videos_to_db(video_list):
    """검색된 영상 정보를 데이터베이스에 저장"""
    for video in video_list:
        YouTubeVideo.objects.update_or_create(
            video_id=video["video_id"],
            defaults={
                "title": video["title"],
                "channel_name": video["channel_name"],
                "published_at": video["published_at"],
                "description": video["description"],
                "thumbnail_url": video["thumbnail_url"],
            }
        )
    print(f"✅ {len(video_list)}개의 영상이 데이터베이스에 저장되었습니다!")

if __name__ == "__main__":
    print("🔍 유튜브 영상 검색 중...")
    videos = search_youtube_videos("팜하니")
    save_videos_to_db(videos)
